sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("MyExtension20080815.MyFioriUI1v1.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);